# Publicarlo desde tu teléfono (sin PC)

Una web con WebAssembly normalmente necesita abrirse desde HTTPS. No abras `index.html` desde la carpeta de descargas como `file://`.

## Opción GitHub Pages
1. En Chrome Android, abre https://github.com/ e inicia sesión o crea una cuenta.
2. Crea un repositorio público llamado `gta-vcs-audio-converter`.
3. Usa **Add file → Upload files** y sube `index.html` desde este ZIP descomprimido. Si tu móvil no puede descomprimirlo, usa ZArchiver para extraer `index.html` y `README.md`.
4. Ve a **Settings → Pages**, elige desplegar desde la rama `main` y la carpeta `/ (root)`, y guarda.
5. Cuando GitHub muestre la URL Pages, ábrela en Chrome y prueba primero con un MP3 corto.

Importante: el código carga el codificador desde el asset de GitHub Releases. Si la descarga falla por CORS, necesitará un ajuste para alojar los archivos WASM en el mismo sitio. No publiques música con copyright ni tu archivo MP3; solo sube los archivos de la aplicación.
