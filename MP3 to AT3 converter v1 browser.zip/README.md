# GTA VCS Audio Converter - MP3 to AT3 (PSP) — v4 navegador

## Objetivo
Interfaz estática para Chrome en Android. La conversión del audio se realiza en el dispositivo usando Web Audio API y el codificador ATRAC3 WebAssembly del proyecto `kai-h/atrac-cleanroom` (release v0.1). No utiliza un servidor propio para subir ni convertir la canción.

## Cómo probar
1. Publica esta carpeta como sitio HTTPS estático (por ejemplo, GitHub Pages). `file://` no es una forma fiable de probar módulos WASM.
2. Abre el sitio en Chrome Android con Internet.
3. Selecciona un MP3 de hasta 13 MiB, elige LP2 (132 kbps) o LP4 (66 kbps) y toca Convertir.
4. Descarga el `.at3`, cambia su extensión a `.gta` en ZArchiver y colócalo en `PSP/SAVEDATA/ULES00502CUSTOMTRACKS/`.

## Dependencias externas
- `fflate` 0.8.2 desde jsDelivr para descomprimir el paquete WASM.
- Paquete `webassembly.zip` de `https://github.com/kai-h/atrac-cleanroom/releases/download/v0.1/webassembly.zip`.
Ambos se cargan en el navegador. El primer uso necesita conexión. La carga del asset de GitHub desde JavaScript puede fallar si el navegador/CDN impide CORS para el archivo de release; en ese caso, hay que alojar los archivos del paquete WASM junto a `index.html` y ajustar el cargador. Esta versión intenta descubrir los archivos JS/WASM dentro del ZIP, pero el empaquetado de upstream podría cambiar.

## Límites y estado
- Máximo de entrada: 13 MiB (13 × 1024 × 1024 bytes).
- La conversión requiere memoria libre en Android: el audio se decodifica en memoria y las canciones largas pueden fallar en móviles con poca RAM.
- La salida RIFF usa el formato ATRAC3 0x0270 y añade `fmt`, `fact` y `data`. El modo LP2 (132 kbps, 384 bytes por trama) es el objetivo principal. LP4/66 kbps se deja disponible, pero la compatibilidad con PSP para ese modo y la aceptación por GTA VCS requieren prueba real.
- No he podido ejecutar este proyecto en Chrome Android desde este entorno ni verificar la salida contra el juego/PPSSPP. Por tanto, es un prototipo de integración, no una conversión certificada. No renombra automáticamente el resultado a `.gta`.

## Codificador
`kai-h/atrac-cleanroom`, MIT, release v0.1. Consulte el README upstream para el estado y limitaciones de la implementación: https://github.com/kai-h/atrac-cleanroom
